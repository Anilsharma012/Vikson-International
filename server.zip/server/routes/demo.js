// server/routes/demo.js
export const handleDemo = (req, res) => {
  res.json({ message: "🎉 Demo route is working!" });
};
